'use strict';

exports.mysql = {
  package: 'egg-mysql',
  enable: true,
};
exports.cors = {
  package: 'egg-cors',
  enable: true,
};
// app.mysql.query();
