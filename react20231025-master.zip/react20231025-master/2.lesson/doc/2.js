
function h1(...args){
console.log(args[0][0])
}
h1`
color:red;
`