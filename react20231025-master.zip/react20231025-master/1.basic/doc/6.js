let home = {city:'北京'}
let a= {
    attr1:0,
    home
}
home.city='上海'
let b= {
  attr1:0,
  home
}