function a(){
    b();
}
function b(){
    c();
}
setTimeout
Promise
let a =1;
let b = 3;
//.........1000W行代码
