let arr = Array.from({length:5},(_,i)=>i);
console.log(arr)