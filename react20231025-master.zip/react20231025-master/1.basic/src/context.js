const ThemeContext = React.createContext('orange');
export default ThemeContext;