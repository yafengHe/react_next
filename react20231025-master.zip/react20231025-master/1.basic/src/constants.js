//此类型表示虚拟DOM是一个文本节点
export const REACT_TEXT = Symbol.for('react.text')
export const REACT_FORWARD_REF = Symbol.for('react.forward_ref');
export const REACT_MEMO = Symbol.for('react.memo');