function Post(){
    return <div>Post</div>
}
export default Post;