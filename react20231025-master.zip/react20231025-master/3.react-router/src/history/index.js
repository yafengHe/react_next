import createBrowserHistory from './createBrowserHistory';
import createHashHistory from './createHashHistory';
export {
    createBrowserHistory,
    createHashHistory
}