
function Foo(){
    return <div>Foo</div>
}
export default Foo;