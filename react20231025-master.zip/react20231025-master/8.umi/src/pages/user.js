import React from 'react';
import styles from './user.less';

export default function Page() {
  return (
    <div>
      <h1 className={styles.title}>Page user</h1>
    </div>
  );
}
