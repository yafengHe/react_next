function Page(){
    return (
        <div>
          UserDetail
        </div>
    )
}
export default Page;