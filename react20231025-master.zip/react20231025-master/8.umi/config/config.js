import routes from './routes';
//这个文件名是定死的，代表UMI项目的配置文件
//导出一个配置对象，routes属性是定死的，代表路由配置数组
//一旦在配置文件里编写了路由配置，那么自动从约定式路由就变成了配置式路由
export default {
    routes
}