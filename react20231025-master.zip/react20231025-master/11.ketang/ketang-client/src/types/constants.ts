export enum LOGIN_STATE{
    UN_VALIDATE='UN_VALIDATE',//尚未验证
    LOGIN_ED='LOGIN_ED',//已登录
    UN_LOGIN='UN_LOGIN'//未登录
}