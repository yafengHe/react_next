## 1.创建项目 
- ts+react18+redux+redux toolkit +tailwindcss
- ts+express+mongodb+ts

```js

```
## 2.tailwindcss
- pt-10
- padding-top 10
- 4=1rem=16px
- 10=2.5rem=40

- 1rem=20
- pt-10=2.5rem=40px+10px=50px




## Transition
动画
React Vue比较类似
isMenuVisible=false

当一个元素从不见到可见，会经过以下的状态
state
entering entered
当一个元素从可见到不可见，会经过以下状态
exiting exited

state exited

state exited
state entering
state entered

state entered
state exiting
state exited


.d.ts和.ts有什么不同

.ts 是一个常规的ts文件
里面可能会有常规的js代码，也可以包括接口和类型 定义

.d.ts扩展名代表ts的类型声明文件
只能用来声明类型，不能包含实际业务逻辑
