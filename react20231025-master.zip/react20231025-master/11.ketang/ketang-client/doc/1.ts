interface A{
    name:string
}
interface B{
    name:string
}
let a:A={name:'lisi'}
let b:B={name:'zhangsan'}
a=b;