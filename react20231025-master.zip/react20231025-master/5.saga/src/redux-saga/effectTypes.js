//监听某个向仓库派发的动作类型
export const TAKE = 'TAKE';
//用来告诉中间件向仓库派发动作
export const PUT = 'PUT';
export const FORK = 'FORK';
export const CALL = 'CALL';
export const CPS = 'CPS';
export const ALL = 'ALL';
export const CANCEL = 'CANCEL';