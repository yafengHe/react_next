export const ADD = 'ADD';
export const ASYNC_ADD = 'ASYNC_ADD';
export const STOP_ADD = 'STOP_ADD';

export const REQUEST = 'REQUEST';
export const STOP_REQUEST = 'STOP_REQUEST';