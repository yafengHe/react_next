### saga的分类
- rootSaga  根saga
- watcher Saga 监听 Saga
- worker saga 工作saga

- 所谓的saga其实就是生成器函数

fork
all
Promise.all(promise数组)

cancel 取消
