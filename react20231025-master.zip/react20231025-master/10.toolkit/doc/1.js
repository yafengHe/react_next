function add(){

}
add.toString = ()=>'some';
let obj = {
    [add]:'value'
}
console.log(obj)